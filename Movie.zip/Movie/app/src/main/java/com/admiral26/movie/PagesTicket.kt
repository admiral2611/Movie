package com.admiral26.movie

import android.os.Bundle
import android.view.View
import com.admiral26.movie.core.base.BaseFragment

class PagesTicket :BaseFragment(R.layout.ticket_pages) {
    override fun onCreated(view: View, savedInstanceState: Bundle?) {

    }
}